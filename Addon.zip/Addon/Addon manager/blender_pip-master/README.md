# blender_pip: Python module manager

<img width="490" alt="image" src="https://user-images.githubusercontent.com/3758308/190018745-52fb472c-79a9-46ea-ab85-cf3ab4843ffc.png">

A Blender addon for managing Python modules inside Blender with PIP. Install either by download .zip or downloading a release. Both should be installable into Blender through the install add-ons interface.

Name in the addon tab: "Development: Python Module Manager"
